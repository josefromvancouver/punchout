package assetpartners.punchout;

import java.util.HashMap;
import java.util.Map;
import java.rmi.RemoteException;

import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.MXSystemException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;
import psdi.security.UserInfo;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboRemote;

/*

Jun 26, 17	jn	stores the data required for an ecomm punchout request
Mar 27, 24	jn commented out any reference to the ariba global values, all data is on the company records
May 19, 24 	jn	commented out lines
					returnUrl.append("&").append(userSessionId);
					returnUrl.append("&csrftoken=").append(csrfToken);
May 28, 24	jn	changed  /webclient/login/ecommreturn.jsp to /webclient/login/appunchoutreturn.jsp
*/

public class PunchoutData implements PunchoutConstants
{
	private Map<String, String> datastore;
	private Map<String, String> defaultstore;
	private Map<String, String> extrinsicstore;
	private MXLogger logger;
	private UserInfo userInfo;

	public MboRemote appMbo;

    public PunchoutData(MXLogger _logger)
    {
		logger = _logger;
		datastore = new HashMap<String, String>();
		defaultstore = new HashMap<String, String>();
		extrinsicstore = new HashMap<String, String>();
    }

    public void initialize(MboRemote _appMbo)
     throws MXException, RemoteException
    {
		appMbo = _appMbo;
		userInfo = appMbo.getUserInfo();
		put(USER, userInfo.getUserName() );
		put(USERLOCALE, userInfo.getLocale().getCountry() );
		put(USEREMAIL, userInfo.getEmail() );
		//get the default constants
		put(USERAGENT, USERAGENT );
		put(CXMLEXTSYS, CXMLEXTSYS);
		put(CXMLDTD, CXMLDTD);
		put(PAYLOADDOMAIN, PAYLOADDOMAIN);
		put(PAYLOADID, System.currentTimeMillis() + "@" + MXServer.getMXServer().getAppServerNameandVersion() );

		putProperty(DEPLOYMENTMODE);
		//mar 27, 24 jn commented out following 5 ariba. properties
		//putProperty(COUNTRYCODE);
		//putProperty(PAYLOADIDDOMAIN);
		//putProperty(PUNCHOUTGLOBALPOURL);
		//putProperty(PUNCHOUTGLOBALURL);
		//putProperty(SUPPLIERDOMAIN);

		putProperty(SUPPLIER_MR_AUXID);
		putProperty(SUPPLIER_PR_AUXID);
		putProperty(SUPPLIER_PO_AUXID);
		putProperty(SETUP_EXTRINSICS);


	}


    public void put(String key, String value)
    {
		datastore.put(key, value);
	}

	public void replace(String key, String value)
	{
		datastore.remove(key);
		datastore.put(key, value);
	}

	public void putProperty(String propertyName)
		throws MXException, RemoteException
	{
		try
		{
			String propertyValue = MXServer.getMXServer().getProperty(propertyName);
			datastore.put(propertyName, propertyValue);
			logDebugMessage("PunchoutData.putProperty=", propertyName + ":" + propertyValue);
		}
		catch (Exception e)
		{
			logDebugMessage("PunchoutData.getDefaultsList error ", e.getMessage() );
			String[] params = { e.getMessage() };
			throw new MXApplicationException("ecommpunchout", "error", params);
		}
	}


	//someplace to store the user entered table defaults
	public void putDefault(String key, String value)
	{
		if ((value != null) && !value.equals(""))
			defaultstore.put(key, value);
	}

	//return a string containing the default values.  This will be attached to the "return url" that is sent to the punchout site.
	//when the url is returned, the default values will be used when inserting records
	private String getUserDefaults()
			throws MXException, RemoteException
	{
		try
		{
			StringBuilder result = new StringBuilder();
			for (Map.Entry<String, String> entry : defaultstore.entrySet())
			{
				String value = java.net.URLEncoder.encode(entry.getValue(), "UTF-8");
				result.append("&").append("d_").append(entry.getKey() ).append("=").append(value );
			}
			return result.toString();
		}
		catch (Exception e)
		{
			logDebugMessage("PunchoutData.getDefaultsList error ", e.getMessage() );
			String[] params = { e.getMessage() };
			throw new MXApplicationException("ecommpunchout", "error", params);
		}

	}

	//someplace to store the user defined extrinsics to add to the punchout setup request xml
	public void putExtrinsic(String key, String value)
				throws MXException, RemoteException
	{
		try
		{
			if ((value != null) && !value.equals(""))
				extrinsicstore.put(key, value);
			logDebugMessage("PunchoutData.putExtrinsic=", key + ":" + value);
		}
		catch (Exception e)
		{
			logDebugMessage("PunchoutData.getDefaultsList error ", e.getMessage() );
			String[] params = { e.getMessage() };
			throw new MXApplicationException("ecommpunchout", "error", params);
		}
	}

	//return a string containing the custom extrinsics.  These will be attached to the setup request that is sent to the punchout site.
	private String getCustomExtrinsics()
			throws MXException, RemoteException
	{
		try
		{
			StringBuilder result = new StringBuilder();
			for (Map.Entry<String, String> entry : extrinsicstore.entrySet())
			{
				String value = java.net.URLEncoder.encode(entry.getValue(), "UTF-8");
				if ( result.length()>0 ) result.append(",");
				result.append(entry.getKey() ).append("@").append(value );
			}
			String extrinsics = result.toString();
			logDebugMessage("PunchoutData.getCustomExtrinsics=", extrinsics);
			return extrinsics;
		}
		catch (Exception e)
		{
			logDebugMessage("PunchoutData.getCustomExtrinsics error ", e.getMessage() );
			String[] params = { e.getMessage() };
			throw new MXApplicationException("ecommpunchout", "error", params);
		}
	}


	public Map<String, String> getCustomExtrinsicsMap()
	{
		return extrinsicstore;
	}


	public String get(String key)
	{
		String value = datastore.get(key);
		if (value == null) value = "";
		return value;
	}

	public void populateSiteEcommData()
		throws MXException, RemoteException
	{
		logDebugMessage("PunchoutData.populateSiteEcommData ", "enter");
		String siteid = get(SITEID);
		// get siteecom data
		MboSetRemote mboSet = MXServer.getMXServer().getMboSet("SITEECOM", userInfo);
		mboSet.setQbeExactMatch(true);
		mboSet.setQbe("orgid", get(ORGID) );
		mboSet.setQbe("siteid", get(SITEID) );
		mboSet.setQbe("vendor", get(COMPANYID) );
		try
		{
			if ( mboSet.moveFirst() == null  )
				throw new MXApplicationException("ecommpunchout", "no_site_ecom_data");
			//put(MKTPLCIDDOMAIN, mboSet.getString(MKTPLCIDDOMAIN) );
			//put(MKTPLCID, mboSet.getString(MKTPLCID) );
			//put(SHAREDSECRET, mboSet.getString(SHAREDSECRET) );
			put(SITE_MKTPLCIDDOMAIN, mboSet.getString("mktplciddomain") );
			put(SITE_MKTPLCID, mboSet.getString("mktplcid") );
			put(SHAREDSECRET, mboSet.getString("custnum") );

/*			//check to see if there is a record specific for the site
			for(MboRemote currMbo=mboSet.moveFirst(); currMbo!=null; currMbo=mboSet.moveNext())
			{
				if ( currMbo.getString("siteid").equals(siteid) )
				{
					put(MKTPLCIDDOMAIN, currMbo.getString(MKTPLCIDDOMAIN) );
					put(MKTPLCID, currMbo.getString(MKTPLCID) );
					put(SHAREDSECRET, currMbo.getString(SHAREDSECRET) );
				}
			}
*/
		}
		finally
		{
			mboSet.close();
			mboSet.clear();
			logDebugMessage("PunchoutData.populateSiteEcommData ", "exit");
		}
	}


	// where to send the punchout request
	// mar 27, 24 jn no more global "ariba." values, alwasys use vendor data
	public String getPunchoutUrl()
			throws MXException, RemoteException
	{

		return get(PUNCHOUTDIRECTURL);
	/*
		//if the vendor has a "punchout direct to vendor url", use it, else use the global punchout url
		logDebugMessage("PunchoutData.getPunchoutUrl ", "enter");
		StringBuilder url = new StringBuilder( );
		if (get(PUNCHOUTDIRECTURL).length() > 0 )
		{
			url.append( get(PUNCHOUTDIRECTURL) );
		}
		else
		{
			url.append( get(PUNCHOUTGLOBALPOURL) );
			url.append("?ANURL=").append( get(PUNCHOUTGLOBALURL) ) ;
			url.append("&APCANID=").append( get(ORG_MKTPLCID) );
			url.append("&SupplierDomain=supplierid." ).append( get(SUPPLIERDOMAIN) );
			url.append("&SupplierIdentity=").append( get(COMPANYID) );
		}

		logDebugMessage("PunchoutData.getPunchoutUrl = ", url.toString() );
		logDebugMessage("PunchoutData.getPunchoutUrl ", "exit");
		return url.toString();

	*/

	}


	//build and save the return url that is passed to ecomm site.  The site will return data to this url
	public void buildReturnUrl(String maximoURL , String userSessionId, String csrfToken)
			throws MXException, RemoteException
	{
		logDebugMessage("PunchoutData.buildReturnUrl ", "enter");
		put(PAYLOADID, System.currentTimeMillis() + "@" + maximoURL );
		StringBuilder returnUrl = new StringBuilder(maximoURL);
		returnUrl.append("/webclient/login/appunchoutreturn.jsp?event=loadapp&value=").append( get(PRESENTATIONID) );
		returnUrl.append("&uniqueid=").append( get(KEYFIELDVALUE) );
		//returnUrl.append("&").append(userSessionId);
		//returnUrl.append("&csrftoken=").append(csrfToken);
		if ( !get(ADDITIONALEVENTVALUE).equals("") )
			returnUrl.append("&additionalevent=gototab&additionaleventvalue=").append( get(ADDITIONALEVENTVALUE)  );
		returnUrl.append("&vendor=").append( get(COMPANYID) );
		returnUrl.append("&orgid=").append( get(ORGID) );
		returnUrl.append( getUserDefaults() );
		put(RETURNURL, returnUrl.toString() );
		logDebugMessage("PunchoutData.buildReturnUrl = ", returnUrl.toString() );
		logDebugMessage("PunchoutData.buildReturnUrl ", "exit");
	}


	// get the shipto info.  If a shipto has been supplied, use it, else use the default shipto address for the site
	public void populateShipToAddress()
		throws RemoteException, MXException
	{
		logDebugMessage("PunchoutData.populateShipToAddress ", "enter");
		String shipto = get(SHIPTO);
		if(shipto != null && shipto.length() > 0)
		{
			logDebugMessage("PunchoutData.populateShipToAddress ", "getting shipto address");
			MboSetRemote mboSet = MXServer.getMXServer().getMboSet("ADDRESS", userInfo);
			mboSet.setQbeExactMatch(true);
			mboSet.setQbe("orgid", get(ORGID) );
			mboSet.setQbe("addresscode", shipto );
			if (!mboSet.moveFirst().equals(null) )
			{
				put(SHIPTODESCRIPTION, mboSet.getString("description") );
				put(SHIPTOADDRESS1, mboSet.getString("address1") );
				put(SHIPTOADDRESS2, mboSet.getString("address2") );
				put(SHIPTOADDRESS3, mboSet.getString("address3") );
				put(SHIPTOADDRESS4, mboSet.getString("address4") );
				put(SHIPTOADDRESS5, mboSet.getString("address5") );
			}
			mboSet.close();
			mboSet.clear();
		}
		else // use the default shipto for the site
		{
			shipto = "";
			logDebugMessage("PunchoutData.populateShipToAddress ", "getting default site.shipto address info");
			MboSetRemote siteSet = MXServer.getMXServer().getMboSet("BILLTOSHIPTO", userInfo);
			siteSet.setQbeExactMatch(true);
			siteSet.setQbe("siteid", get(SITEID) );
			for(MboRemote currMbo=siteSet.moveFirst(); currMbo!=null; currMbo=siteSet.moveNext())
			{
				if ( currMbo.getBoolean("shiptodefault") )
					shipto = siteSet.getString("addresscode");
				if ( currMbo.getBoolean("shipto") && shipto.equals("") )
					shipto = siteSet.getString("addresscode");
			}
			siteSet.close();
			//if a shipto address for the site was found, look up the address data
			if (!shipto.equals(""))
			{
				put(SHIPTO, shipto);
				MboSetRemote addressSet = MXServer.getMXServer().getMboSet("Address", userInfo);
				addressSet.setQbeExactMatch(true);
				addressSet.setQbe("addresscode", shipto );
				addressSet.setQbe("orgid", get(ORGID) );
				if ( !addressSet.moveFirst().equals(null) )
				{
					put(SHIPTODESCRIPTION, addressSet.getString("description") );
					put(SHIPTOADDRESS1, addressSet.getString("address1") );
					put(SHIPTOADDRESS2, addressSet.getString("address2") );
					put(SHIPTOADDRESS3, addressSet.getString("address3") );
					put(SHIPTOADDRESS4, addressSet.getString("address4") );
					put(SHIPTOADDRESS5, addressSet.getString("address5") );
				}
				addressSet.close();
				addressSet.clear();
			}
		}
		logDebugMessage("PunchoutData.populateShipToAddress ", "exit");
	}


	private void logDebugMessage(String a, String b)
		throws MXException, RemoteException
	{
		if (logger == null)
			System.out.println("PunchoutData.logDebugMessage logger is null: " + a + " " + b);
		else
		{
			if ( logger.isDebugEnabled() )
				logger.debug(a + b);
		}

	}


}